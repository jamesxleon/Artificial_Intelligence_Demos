from inference import *

drones = ["Belhino", "Motomiya", "Suzutake", "Zarobitchi"]
heights = ["350ft", "475ft", "650ft", "1000ft"]
prices = ["450$", "525$", "600$", "675$"]

symbols = []

knowledge = And()

symbols = drones + heights + prices

def check_knowledge(knowledge):
    #write a check_knowledge function to match the drones to their heights and prices:
    for drone in drones:
        for height in heights:
            for price in prices:
                if model_check(knowledge, drone) == True and model_check(knowledge, height) == True and model_check(knowledge, price) == True:
                    print(f"{drone} is {height} and {price}")
                    break
                else:
                    continue
    

check_knowledge(knowledge)